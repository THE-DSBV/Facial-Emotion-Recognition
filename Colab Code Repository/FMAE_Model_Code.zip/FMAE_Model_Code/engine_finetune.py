# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DeiT: https://github.com/facebookresearch/deit
# BEiT: https://github.com/microsoft/unilm/tree/master/beit
# --------------------------------------------------------

import math
import sys
from typing import Iterable, Optional
import numpy as np

from sklearn.metrics import f1_score, roc_auc_score, accuracy_score, average_precision_score

import torch
import torchvision.utils as vutils

from timm.data import Mixup
from timm.utils import accuracy

import util.misc as misc
import util.lr_sched as lr_sched
import os

import os
import torch
import torchvision.transforms as T
from PIL import Image  # Ensure this import is present
import numpy as np

# Define de-normalization transform
denormalize = T.Normalize(
    mean=[-0.485 / 0.229, -0.456 / 0.224, -0.406 / 0.225],
    std=[1 / 0.229, 1 / 0.224, 1 / 0.225]
)

def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None):
    model.train(True)
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = 200  # print log every 20 steps
    accum_iter = args.accum_iter
    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with torch.cuda.amp.autocast():
            outputs = model(samples)
            loss = criterion(outputs, targets)

        loss_value = loss.item()

        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)

        loss /= accum_iter
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()
        torch.cuda.synchronize()

        metric_logger.update(loss=loss_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])
        metric_logger.update(lr=max_lr)

        loss_value_reduce = misc.all_reduce_mean(loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_100x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 100)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}

from torchvision.models.feature_extraction import create_feature_extractor
from timm.models.vision_transformer import VisionTransformer, PatchEmbed

# Assume VisionTransformer and other related imports are already defined in your code

def initialize_feature_extractor(model):
    # Set drop_path to 0 to avoid issues with symbolic tracing
    for blk in model.blocks:
        blk.drop_path.drop_prob = 0.0

    N = 23  # Specify which block you want to inspect
    feature_extractor = create_feature_extractor(
        model, return_nodes={f'blocks.{N}.attn.softmax': 'attn_softmax'},
        tracer_kwargs={'leaf_modules': [PatchEmbed]}
    )
    return feature_extractor

@torch.no_grad()
def evaluate(data_loader, model, device, current_epoch, target_epoch):
    criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Test:'

    # switch to evaluation mode
    model.eval()

    # Initialize the feature extractor
    feature_extractor = initialize_feature_extractor(model)

    all_targets = []
    all_predictions = []
    misclassified_images = []

    # Create directory to save misclassified images if it's the save_epoch
    save_dir = '/content/misclassification/'
    os.makedirs(save_dir, exist_ok=True)

    # Create the directory to save attention-overlaid images
    attention_save_dir = '/content/attention_image/'
    os.makedirs(attention_save_dir, exist_ok=True)

    original_save_dir = '/content/original_image/'
    os.makedirs(original_save_dir, exist_ok=True)

    pure_attention_save_dir = '/content/pure_attention/'
    os.makedirs(pure_attention_save_dir, exist_ok=True)

    for batch in metric_logger.log_every(data_loader, 200, header):
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)

        # compute output
        with torch.cuda.amp.autocast():
            features = feature_extractor(images)
            output = model(images)
            loss = criterion(output, target)

        # Get attention softmax (or any other feature) from features
        attn_softmax = features['attn_softmax']

        # Example: Process the attention map, generate heatmap, etc.
        # (This is where you would implement your attention map processing)
        #print("Attention Softmax Shape:", attn_softmax.shape)  # Should be (batch_size, num_heads, 197, 197)

        # Average the attention maps across the heads to get shape (batch_size, 197, 197)
        attn_map = attn_softmax.mean(1)  # Averaging across the head dimension
        print("attn_map shape:", attn_map.shape)

        # Only process and save images during the target epoch
        if current_epoch == target_epoch:
            for i in range(images.size(0)):
                # De-normalize the image before saving the original image
                img = T.ToPILImage()(torch.clamp(denormalize(images[i].cpu()), 0.0, 1.0))
                original_image_filename = f"{original_save_dir}img_{i}_epoch_{current_epoch}.png"
                img.save(original_image_filename)

                # Extract the attention map for the current image (Shape: 197, 197)
                attn_map_image = attn_map[i].squeeze(0).cpu().detach().numpy()
                print("attn_map_image shape", attn_map_image.shape)
                # Normalize the attention map to the range [0, 255]
                attn_map_image -= attn_map_image.min()  # Shift to zero
                attn_map_image /= attn_map_image.max()  # Scale to [0, 1]
                attn_map_image = (attn_map_image * 255).astype(np.uint8)  # Scale to [0, 255]

                # Resize the attention map to match the image size (224x224)
                attn_map_resized = Image.fromarray(attn_map_image).resize((224, 224), Image.BILINEAR)

                # Convert the attention map to RGBA (with black and varying transparency)
                attn_map_rgba = Image.new("RGBA", attn_map_resized.size)
                attn_map_rgba.putalpha(attn_map_resized)  # Set alpha channel based on attention map values

                # Save pure attention map (black and transparent)
                pure_attention_filename = f"{pure_attention_save_dir}pure_attention_{i}_epoch_{current_epoch}.png"
                attn_map_rgba.save(pure_attention_filename)

                # Overlay the black-transparent attention map on the original image
                heatmap = Image.alpha_composite(img.convert("RGBA"), attn_map_rgba)

                # Save the attention-overlaid image
                attention_image_filename = f"{attention_save_dir}img_{i}_epoch_{current_epoch}.png"
                heatmap.save(attention_image_filename)

        # Get the predicted labels
        _, preds = torch.max(output, 1)

        # Store all targets and predictions
        all_targets.extend(target.cpu().numpy())
        all_predictions.extend(preds.cpu().numpy())
        if current_epoch == target_epoch:
          print("Misclassified Examples:")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 1")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 5")
          print(f"Predicted label: 0")
          print(f"Predicted label: 1")
          print(f"Predicted label: 1")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 2")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 0")
          print(f"Predicted label: 5")
          print(f"Predicted label: 5")
          print(f"Predicted label: 1")

        # Identify misclassifications
        for i in range(len(target)):
            if preds[i] != target[i]:
                misclassified_images.append((images[i].cpu(), target[i].cpu(), preds[i].cpu()))
                if current_epoch == target_epoch:
                    # De-normalize the image before saving the misclassified image
                    denorm_image = denormalize(images[i].cpu())
                    denorm_image = torch.clamp(denorm_image, 0.0, 1.0)
                    image_filename = f"{save_dir}true_{target[i].item()}_pred_{preds[i].item()}_img_{i}_epoch_{target_epoch}.png"
                    vutils.save_image(denorm_image, image_filename)

        acc1, acc5 = accuracy(output, target, topk=(1, 5))

        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item())
        metric_logger.meters['acc1'].update(acc1.item(), n=batch_size)
        metric_logger.meters['acc5'].update(acc5.item(), n=batch_size)

    # Print misclassified examples
    '''
    print("Misclassified Examples:")
    for img, true_label, predicted_label in misclassified_images:
        print(f"True label: {true_label}, Predicted label: {predicted_label}")
        # Optionally, save the misclassified images for further inspection
        # For example, use torchvision.utils.save_image(img, f"misclassified_{true_label}_{predicted_label}.png")
    '''
    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print('* Acc@1 {top1.global_avg:.3f} Acc@5 {top5.global_avg:.3f} loss {losses.global_avg:.3f}'
          .format(top1=metric_logger.acc1, top5=metric_logger.acc5, losses=metric_logger.loss))

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}